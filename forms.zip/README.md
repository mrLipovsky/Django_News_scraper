# J&T formuláře

Pro každý z formulářů musí samostatně platit následující:

- Soubory `index.html`, `script.js`, `style.css` jsou všechny umístěny v jedné společné složce na stejné úrovni
- Všechny tyto soubory jsou dostupné přes HTTPS na veřejné adrese
- Po úspěšném odeslání formuláře skript zavolá funkci `onFormSuccess` (implementováno v `index.html`)
- Po nezdařeném odeslání formuláře skript zavolá funkci `onFormError` (implementováno v `index.html`)
- Soubor `index.html` je jako jediný možné upravovat (zejména přidání skriptů pro odeslání dat do systémů J&T)

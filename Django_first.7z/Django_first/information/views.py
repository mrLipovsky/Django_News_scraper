from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def index(request):
    return HttpResponse("<h1>Hlavna stranka o zvieratach.</h1>")

def slon(request):
    return HttpResponse("Slon ma velky chobot.")

def zirafa(request):
    return HttpResponse("<p>Zirafa ma dlhy krk.</p>")
from django.urls import path

from . import views
# . znamena aktualny folder

urlpatterns = [
    path("index", views.index),
    path("slon", views.slon),
    path("zirafa", views.zirafa)
]